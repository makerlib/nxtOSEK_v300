/* Report Generator v3.8 (R2010a) で生成 */
var gHomeSys = "balancer";
var gNumSys = 12;
var gFrameID = {
"frameset_main":"balancer_slwebview_main_frameset",
"explorer":"balancer_slwebview_explorer",
"frameset_model":"balancer_slwebview_frame",
"model":"balancer_slwebview_model",
"web":"balancer_slwebview_web"};
var gIDMap = {
"balancer":{"target":"slwebview_1.svg","thumb":"slwebview_1_tb.png"},
"balancer/Control":{"target":"slwebview_2.svg","thumb":"slwebview_2_tb.png"},
"balancer/Control/Cal_PWM":{"target":"slwebview_3.svg","thumb":"slwebview_3_tb.png"},
"balancer/Control/Cal_Reference":{"target":"slwebview_4.svg","thumb":"slwebview_4_tb.png"},
"balancer/Control/Cal_x1":{"target":"slwebview_5.svg","thumb":"slwebview_5_tb.png"},
"balancer/Control/DiscreteIntegrator":{"target":"slwebview_6.svg","thumb":"slwebview_6_tb.png"},
"balancer/Control/Cal_PWM/Cal_vol_max":{"target":"slwebview_7.svg","thumb":"slwebview_7_tb.png"},
"balancer/Control/Cal_Reference/DiscreteIntegrator":{"target":"slwebview_8.svg","thumb":"slwebview_8_tb.png"},
"balancer/Control/Cal_Reference/LowPathFilter":{"target":"slwebview_9.svg","thumb":"slwebview_9_tb.png"},
"balancer/Control/Cal_x1/DiscreteDerivative":{"target":"slwebview_10.svg","thumb":"slwebview_10_tb.png"},
"balancer/Control/Cal_x1/DiscreteIntegrator":{"target":"slwebview_11.svg","thumb":"slwebview_11_tb.png"},
"balancer/Control/Cal_x1/LowPathFilter":{"target":"slwebview_12.svg","thumb":"slwebview_12_tb.png"}};

