var gMsgMap = {
"NoSVGSupport":"<p><b>SVG レンダラが必要です</b>: ブラウザは Scalable Vector Graphics をサポートしていません。</p><p>この Simulink モデルを表示するには、フリーの <a href=\"http://www.adobe.com/svg/viewer/install/\">Adobe SVG Viewer</a> のプラグイン、または <a href=\"http://www.mozilla.org/products/firefox/all\">SVG-compatible web browser</a> をインストールしてください。</p><p>インストール終了後、このウィンドウを閉じてから再度 Web 表示を行ってください。</p>"
};
