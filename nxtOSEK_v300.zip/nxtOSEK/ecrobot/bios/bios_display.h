#ifndef _BIOS_DISPLAY_H_
#define _BIOS_DISPLAY_H_

extern void display_progress_bar(int row, int progress, int max_progress);
extern void display_bios_status(int data, int max_data);

#endif
