var classecrobot_1_1_sensor =
[
    [ "Sensor", "classecrobot_1_1_sensor.html#af9869fd958f21d8cd78112450823bfec", null ],
    [ "~Sensor", "classecrobot_1_1_sensor.html#a3f92ce59eafdbd3b8005fa76767cd016", null ],
    [ "get", "classecrobot_1_1_sensor.html#a925d9e3d3f6b54e312c2b9bb1d0e1dbb", null ],
    [ "getPort", "classecrobot_1_1_sensor.html#abce088139bc8512a2a4507c4e753dc7f", null ]
];