var classecrobot_1_1_light_sensor =
[
    [ "LightSensor", "classecrobot_1_1_light_sensor.html#ab82c8d96746a741f194208f6712b2c15", null ],
    [ "~LightSensor", "classecrobot_1_1_light_sensor.html#ad47c4cc6671eb98f0ab55fdb863dbe57", null ],
    [ "get", "classecrobot_1_1_sensor.html#a925d9e3d3f6b54e312c2b9bb1d0e1dbb", null ],
    [ "getBrightness", "classecrobot_1_1_light_sensor.html#a54dbe2cb8df4a8b957547db3c36fbbd0", null ],
    [ "getPort", "classecrobot_1_1_sensor.html#abce088139bc8512a2a4507c4e753dc7f", null ],
    [ "setLamp", "classecrobot_1_1_light_sensor.html#aa98e40c8fd604e429fef550c2e102d0b", null ]
];