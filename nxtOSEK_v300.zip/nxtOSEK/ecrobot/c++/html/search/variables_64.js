var searchData=
[
  ['data_5fbuffer_5fbyte_5fsize',['DATA_BUFFER_BYTE_SIZE',['../classecrobot_1_1_p_s_p_nx.html#a8f50ffe50a8bfbfc92369cd73baed438',1,'ecrobot::PSPNx']]],
  ['default_5foffset',['DEFAULT_OFFSET',['../classecrobot_1_1_gyro_sensor.html#a2eed5d4763fa145c6c87ab451b73197e',1,'ecrobot::GyroSensor']]],
  ['disable_5ftracking',['DISABLE_TRACKING',['../classecrobot_1_1_camera.html#abec41aee1620447052f477d5e72ca1c8',1,'ecrobot::Camera']]]
];
