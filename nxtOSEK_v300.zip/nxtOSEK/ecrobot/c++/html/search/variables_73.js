var searchData=
[
  ['set_5fadpa_5foff',['SET_ADPA_OFF',['../classecrobot_1_1_camera.html#a5720ea738662a071a76f055c8b415f04',1,'ecrobot::Camera']]],
  ['set_5fadpa_5fon',['SET_ADPA_ON',['../classecrobot_1_1_camera.html#adf15bdee4c4f7bc34eca24ffeed9f5d2',1,'ecrobot::Camera']]],
  ['set_5fcolor_5fmap',['SET_COLOR_MAP',['../classecrobot_1_1_camera.html#a2738574f42dc16112189dde96b6d657a',1,'ecrobot::Camera']]],
  ['sort_5fobj_5fby_5fcolor',['SORT_OBJ_BY_COLOR',['../classecrobot_1_1_camera.html#a09232436e591469b754fd9afb2a222ff',1,'ecrobot::Camera']]],
  ['sort_5fobj_5fby_5fsize',['SORT_OBJ_BY_SIZE',['../classecrobot_1_1_camera.html#a526bf436dfc3e92d8028bc95f3ddf020',1,'ecrobot::Camera']]]
];
