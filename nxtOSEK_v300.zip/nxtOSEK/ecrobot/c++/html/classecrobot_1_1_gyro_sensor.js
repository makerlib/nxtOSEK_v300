var classecrobot_1_1_gyro_sensor =
[
    [ "GyroSensor", "classecrobot_1_1_gyro_sensor.html#a1af0307e41be30b0862e6b516f9b5b7f", null ],
    [ "get", "classecrobot_1_1_sensor.html#a925d9e3d3f6b54e312c2b9bb1d0e1dbb", null ],
    [ "getAnglerVelocity", "classecrobot_1_1_gyro_sensor.html#a65aa2b6c239a308650523546a0340b3d", null ],
    [ "getPort", "classecrobot_1_1_sensor.html#abce088139bc8512a2a4507c4e753dc7f", null ],
    [ "setOffset", "classecrobot_1_1_gyro_sensor.html#a68d1c1f320d4fad20e518c6eb7268752", null ],
    [ "DEFAULT_OFFSET", "classecrobot_1_1_gyro_sensor.html#a2eed5d4763fa145c6c87ab451b73197e", null ]
];